#include "comm_file.h"
#include "comm_impl.h"
#include "cnc_comm.h"
#include "miniutils.h"
#include "spi_flash.h"
#include "spi_flash_m25p16.h"
#include "bootloader_exec.h"

typedef struct  __attribute__ (( packed )) {
  u8_t cmd; // always 0x80
  u32_t sequence;
  u32_t length;
  u8_t name[8];
} comm_file_hdr ;

typedef struct  __attribute__ (( packed ))  {
  u8_t ack; // always 0x81
  u8_t res;
  u32_t last_stored_pkt_in_sequence;
} comm_file_ack;

static struct {
  bool active;
  u32_t length;
  u32_t index;
  u32_t last_stored_sequence;
  u8_t last_pkt_len;
} state;

static void _comm_file_spif_cb(spi_flash_dev *dev, int result) {
  DBG(D_SYS, D_DEBUG, "comm file spif cb res:%i\n", result);
  comm_file_ack a;
  a.ack = COMM_PROTOCOL_FILE_TRANSFER_A;
  if (result != SPI_OK) {
    a.res = COMM_FILE_ERR_ABORT;
    a.last_stored_pkt_in_sequence = 0xffffffff;
    state.active = FALSE;
    COMM_tx(COMM_CONTROLLER_ADDRESS, (u8_t*)&a, sizeof(comm_file_ack), TRUE);
  } else {
    a.res = COMM_FILE_REPLY_OK;
    a.last_stored_pkt_in_sequence = state.last_stored_sequence;

    if (state.last_pkt_len > 0) {
      state.index += state.last_pkt_len;
      state.last_stored_sequence++;
    }

    DBG(D_SYS, D_DEBUG, "comm file stored %i of %i\n", state.index, state.length);
    if (state.index == state.length) {
      state.active = FALSE;
      DBG(D_SYS, D_DEBUG, "comm file finished\n");
    } else {
      s32_t res = COMM_tx(COMM_CONTROLLER_ADDRESS, (u8_t*)&a, sizeof(comm_file_ack), TRUE);
      if (res < R_COMM_OK) {
        DBG(D_SYS, D_WARN, "comm file tx ack error %i\n", res);
      }
    }
  }
}

s32_t COMM_FILE_on_pkt(u8_t *data, u8_t len) {
  s32_t res = R_COMM_OK;
  u8_t reply;
  comm_file_hdr *h = (comm_file_hdr *)data;
  DBG(D_SYS, D_DEBUG, "comm file got request, seq: %08x\n", h->sequence);
  if (h->sequence == 0xffffffff) {
    // request to store file
    DBG(D_SYS, D_DEBUG, "comm file got file header, len: %i, name: %s\n", h->length, h->name);
    if (state.active) {
      reply = COMM_FILE_ERR_UNEXPECTED;
      COMM_reply(&reply, 1);
      return R_COMM_OK;
    }
    if (h->length > FLASH_TOTAL_SIZE) {
      reply = COMM_FILE_ERR_NO_SPACE;
      COMM_reply(&reply, 1);
      return R_COMM_OK;
    }
    reply = COMM_FILE_REPLY_OK;
    COMM_reply(&reply, 1);
    state.active = TRUE;
    state.last_stored_sequence = 0;
    state.last_pkt_len = 0;
    state.index = 0;
    state.length = h->length;
    SPI_FLASH_erase(SPI_FLASH, _comm_file_spif_cb, FIRMWARE_SPIF_ADDRESS, h->length);
  } else {
    // request to store packet
    DBG(D_SYS, D_DEBUG, "comm file got pkt, seq:%i len: %i\n", h->sequence, len - offsetof(comm_file_hdr, length));
    if (!state.active) {
      reply = COMM_FILE_ERR_UNEXPECTED;
      COMM_reply(&reply, 1);
      return R_COMM_OK;
    } else if (len <= offsetof(comm_file_hdr, length)) {
      reply = COMM_FILE_ERR_ABORT;
      COMM_reply(&reply, 1);
      return R_COMM_OK;
    }
    reply = COMM_FILE_REPLY_OK;
    COMM_reply(&reply, 1);

    if (h->sequence == state.last_stored_sequence + 1) {
      state.last_pkt_len = len - offsetof(comm_file_hdr, length);
      SPI_FLASH_write(
          SPI_FLASH,
          _comm_file_spif_cb,
          FIRMWARE_SPIF_ADDRESS + h->sequence * COMM_FILE_MAX_DATA_PKT,
          len - offsetof(comm_file_hdr, length),
          &data[offsetof(comm_file_hdr, length)]);
    }
  }
  return res;
}

void COMM_FILE_init() {
  memset(&state, 0, sizeof(state));
}
