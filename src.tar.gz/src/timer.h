/*
 * timer.h
 *
 *  Created on: Jun 23, 2012
 *      Author: petera
 */

#ifndef TIMER_H_
#define TIMER_H_

void TIMER_irq();

#endif /* TIMER_H_ */
