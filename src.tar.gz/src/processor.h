/*
 * processor.h
 *
 *  Created on: Aug 1, 2012
 *      Author: petera
 */

#ifndef PROCESSOR_H_
#define PROCESSOR_H_

void PROC_base_init();
void PROC_periph_init();

void PROC_periph_init_bootloader();

#endif /* PROCESSOR_H_ */
