/*
 * console.h
 *
 *  Created on: Jul 24, 2012
 *      Author: petera
 */

#ifndef CONSOLE_H_
#define CONSOLE_H_

void DBG_init();
void DBG_timer();

#endif /* CONSOLE_H_ */
